<?php
$name=$_POST['name'];
if($name=='rafik'){
	echo 'welcome '.$name;
}
?>